# Présence Boulangerie – application Android de pointage

Application Android (Kotlin + Jetpack Compose) pour suivre la présence des employés d'une boulangerie.

- **Un seul téléphone** (ou tablette) fixe à la boulangerie sert de borne de pointage.
- Chaque employé a **sa carte avec un QR code personnel**. Il le montre à la caméra : l'application enregistre l'**arrivée** au premier scan et le **départ** au scan suivant.
- **Fonctionne sans internet** : tout est stocké sur le téléphone.
- **Espace patron** protégé par un code PIN (par défaut : `1234` – à changer dès le premier jour).

## Fonctions

| Écran | Ce qu'il fait |
|---|---|
| Pointage (accueil) | Caméra qui scanne les QR codes, message clair (bonjour / au revoir + durée), petit bip |
| Aujourd'hui | Liste des pointages du jour (navigation jour par jour), clôture d'un départ oublié, suppression |
| Employés | Ajouter un employé, activer/désactiver, afficher / partager / imprimer sa carte QR |
| Rapport | Total d'heures et jours travaillés par employé et par mois, export CSV (ouvrable dans Excel) |
| Réglages | Changement du code PIN |

Règles automatiques :
- Deux scans à moins de 60 secondes sont ignorés (évite les doubles pointages).
- Si un employé a oublié de pointer son départ depuis plus de 16 h, son ancien pointage est fermé à durée nulle et une nouvelle arrivée est enregistrée. Le patron peut corriger dans l'onglet « Aujourd'hui ».

## Installation

1. Installer **Android Studio** (https://developer.android.com/studio) sur un ordinateur.
2. Menu **File > Open**, choisir le dossier `PresenceBoulangerie`.
3. Attendre la synchronisation Gradle (la première fois, une connexion internet est nécessaire pour télécharger les bibliothèques). Si Android Studio propose de choisir ou mettre à jour Gradle, acceptez.
4. Brancher le téléphone Android (mode développeur + débogage USB activés) et cliquer sur **Run ▶**.
5. Pour obtenir un fichier APK à installer sur d'autres téléphones : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Android 8.0 (API 26) minimum.

## Premiers pas

1. Ouvrir l'app, appuyer sur **Espace patron**, entrer `1234`.
2. Onglet **Réglages** : changer le code PIN.
3. Onglet **Employés** : ajouter chaque employé, puis **QR code > Partager / Imprimer** pour obtenir sa carte (image PNG à imprimer ou envoyer par WhatsApp).
4. Laisser le téléphone sur l'écran d'accueil : les employés présentent leur carte à la caméra en arrivant et en partant.
5. En fin de mois : onglet **Rapport**, choisir le mois, **Exporter**.

## Limites actuelles

- Les données restent **uniquement sur ce téléphone** : s'il est perdu ou réinitialisé, elles disparaissent. Pensez à exporter le rapport CSV chaque mois.
- Un QR code peut être photographié et prêté à un collègue. Si cela pose problème, un code PIN par employé ou une photo au pointage pourrait être ajouté.
- Le code PIN protège l'accès dans l'application, pas le fichier de données du téléphone.

## Structure du code

```
app/src/main/java/com/boulangerie/presence/
  MainActivity.kt          navigation Accueil / PIN / Patron
  data/Database.kt         tables Employee et Shift (Room)
  data/Repository.kt       logique arrivée / départ
  ui/AppViewModel.kt       état de l'application, PIN
  ui/screens/              HomeScreen (scan), PinScreen, BossScreen
  util/                    QR codes, export CSV, formats, totaux
```
