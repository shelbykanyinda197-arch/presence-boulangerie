package com.boulangerie.presence.data

import java.util.UUID

const val QR_PREFIX = "PRESENCE:"

/** Délai minimum entre deux pointages d'une même personne (évite les doubles scans). */
private const val MIN_GAP_MS = 60_000L

/** Au-delà de cette durée, un pointage d'arrivée sans départ est considéré comme oublié. */
private const val MAX_SHIFT_MS = 16 * 3_600_000L

sealed class ScanResult {
    data class CheckedIn(val name: String, val time: Long, val forgotPreviousDeparture: Boolean) : ScanResult()
    data class CheckedOut(val name: String, val time: Long, val durationMs: Long) : ScanResult()
    data class TooSoon(val name: String) : ScanResult()
    data class Inactive(val name: String) : ScanResult()
    data object Unknown : ScanResult()
}

class Repository(private val dao: AppDao) {

    fun newCode(): String = UUID.randomUUID().toString().replace("-", "").take(12)

    suspend fun addEmployee(name: String, role: String) {
        dao.insertEmployee(Employee(name = name.trim(), role = role.trim(), code = newCode()))
    }

    /**
     * Un scan = arrivée si la personne n'est pas "en poste", sinon départ.
     */
    suspend fun handleScan(raw: String, now: Long): ScanResult {
        if (!raw.startsWith(QR_PREFIX)) return ScanResult.Unknown
        val employee = dao.employeeByCode(raw.removePrefix(QR_PREFIX)) ?: return ScanResult.Unknown
        if (!employee.active) return ScanResult.Inactive(employee.name)

        val open = dao.openShift(employee.id)
        if (open != null) {
            val age = now - open.checkIn
            if (age < MIN_GAP_MS) return ScanResult.TooSoon(employee.name)
            if (age > MAX_SHIFT_MS) {
                // Départ oublié : on ferme l'ancien pointage à durée nulle et on démarre une nouvelle journée.
                dao.updateShift(open.copy(checkOut = open.checkIn))
                dao.insertShift(Shift(employeeId = employee.id, checkIn = now))
                return ScanResult.CheckedIn(employee.name, now, forgotPreviousDeparture = true)
            }
            dao.updateShift(open.copy(checkOut = now))
            return ScanResult.CheckedOut(employee.name, now, age)
        }

        val lastOut = dao.lastShift(employee.id)?.checkOut
        if (lastOut != null && now - lastOut < MIN_GAP_MS) return ScanResult.TooSoon(employee.name)

        dao.insertShift(Shift(employeeId = employee.id, checkIn = now))
        return ScanResult.CheckedIn(employee.name, now, forgotPreviousDeparture = false)
    }
}
