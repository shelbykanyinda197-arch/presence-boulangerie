package com.boulangerie.presence.ui

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val BakeryColors = lightColorScheme(
    primary = Color(0xFF8B5A2B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE0B2),
    onPrimaryContainer = Color(0xFF3E2200),
    secondary = Color(0xFFC77D2E),
    background = Color(0xFFFFF8F0),
    surface = Color(0xFFFFF8F0),
    surfaceVariant = Color(0xFFF3E3D0)
)

val GreenOk = Color(0xFFD7F0D9)
val BlueInfo = Color(0xFFD6E8FA)
val OrangeWarn = Color(0xFFFFE8B8)
val RedErr = Color(0xFFF8D4D0)

@Composable
fun BoulangerieTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BakeryColors, content = content)
}

@Composable
fun Header(title: String, actionLabel: String, onAction: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.primary, contentColor = Color.White) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(
                onClick = onAction,
                colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) { Text(actionLabel) }
        }
    }
}
