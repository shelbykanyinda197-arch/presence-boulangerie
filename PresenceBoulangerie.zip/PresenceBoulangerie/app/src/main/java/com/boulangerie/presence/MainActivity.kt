package com.boulangerie.presence

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.boulangerie.presence.ui.AppViewModel
import com.boulangerie.presence.ui.BoulangerieTheme
import com.boulangerie.presence.ui.screens.BossScreen
import com.boulangerie.presence.ui.screens.HomeScreen
import com.boulangerie.presence.ui.screens.PinScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BoulangerieTheme {
                AppRoot()
            }
        }
    }
}

private enum class Screen { HOME, PIN, BOSS }

@Composable
private fun AppRoot() {
    val vm: AppViewModel = viewModel()
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    when (screen) {
        Screen.HOME -> HomeScreen(vm, onBoss = { screen = Screen.PIN })
        Screen.PIN -> PinScreen(vm, onSuccess = { screen = Screen.BOSS }, onCancel = { screen = Screen.HOME })
        Screen.BOSS -> BossScreen(vm, onExit = { screen = Screen.HOME })
    }
}
