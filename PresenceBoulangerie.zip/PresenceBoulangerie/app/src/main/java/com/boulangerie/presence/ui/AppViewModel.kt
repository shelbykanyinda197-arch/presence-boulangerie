package com.boulangerie.presence.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.boulangerie.presence.data.AppDatabase
import com.boulangerie.presence.data.Employee
import com.boulangerie.presence.data.Repository
import com.boulangerie.presence.data.ScanResult
import com.boulangerie.presence.data.Shift
import com.boulangerie.presence.util.startOfDayMillis
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).dao()
    private val repo = Repository(dao)
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val employees: StateFlow<List<Employee>> =
        dao.employees().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // ---------- Pointage ----------

    val scanResult = MutableStateFlow<ScanResult?>(null)
    private var lastCode: String? = null
    private var lastSeenAt = 0L
    private var clearJob: Job? = null

    fun onCodeScanned(raw: String) {
        val now = System.currentTimeMillis()
        // Tant que le même QR code reste devant la caméra, on ne le retraite pas.
        if (raw == lastCode && now - lastSeenAt < 5_000) {
            lastSeenAt = now
            return
        }
        lastCode = raw
        lastSeenAt = now
        viewModelScope.launch {
            scanResult.value = repo.handleScan(raw, now)
            clearJob?.cancel()
            clearJob = launch {
                delay(4_000)
                scanResult.value = null
            }
        }
    }

    // ---------- Journée ----------

    val selectedDay = MutableStateFlow(LocalDate.now())

    val dayShifts: StateFlow<List<Shift>> = selectedDay
        .flatMapLatest { d -> dao.shiftsBetween(startOfDayMillis(d), startOfDayMillis(d.plusDays(1))) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun shiftDay(delta: Long) {
        selectedDay.value = selectedDay.value.plusDays(delta)
    }

    fun deleteShift(shift: Shift) {
        viewModelScope.launch { dao.deleteShift(shift.id) }
    }

    fun closeShiftNow(shift: Shift) {
        viewModelScope.launch { dao.updateShift(shift.copy(checkOut = System.currentTimeMillis())) }
    }

    // ---------- Rapport mensuel ----------

    val selectedMonth = MutableStateFlow(YearMonth.now())

    val monthShifts: StateFlow<List<Shift>> = selectedMonth
        .flatMapLatest { m ->
            dao.shiftsBetween(startOfDayMillis(m.atDay(1)), startOfDayMillis(m.plusMonths(1).atDay(1)))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun shiftMonth(delta: Long) {
        selectedMonth.value = selectedMonth.value.plusMonths(delta)
    }

    // ---------- Employés ----------

    fun addEmployee(name: String, role: String) {
        if (name.isBlank()) return
        viewModelScope.launch { repo.addEmployee(name, role) }
    }

    fun setActive(employee: Employee, active: Boolean) {
        viewModelScope.launch { dao.updateEmployee(employee.copy(active = active)) }
    }

    // ---------- Code PIN du patron ----------

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(("boulangerie-salt:" + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun storedHash(): String = prefs.getString("pin_hash", null) ?: hash(DEFAULT_PIN)

    fun checkPin(pin: String): Boolean = hash(pin) == storedHash()

    fun isDefaultPin(): Boolean = storedHash() == hash(DEFAULT_PIN)

    /** @return true si le changement a réussi. */
    fun changePin(oldPin: String, newPin: String): Boolean {
        if (!checkPin(oldPin) || newPin.length < 4) return false
        prefs.edit().putString("pin_hash", hash(newPin)).apply()
        return true
    }

    companion object {
        const val DEFAULT_PIN = "1234"
    }
}
