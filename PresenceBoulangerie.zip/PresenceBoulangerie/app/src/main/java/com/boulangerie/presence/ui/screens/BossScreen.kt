package com.boulangerie.presence.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.boulangerie.presence.data.Employee
import com.boulangerie.presence.data.Shift
import com.boulangerie.presence.ui.AppViewModel
import com.boulangerie.presence.ui.Header
import com.boulangerie.presence.util.employeeQr
import com.boulangerie.presence.util.exportMonthCsv
import com.boulangerie.presence.util.fmtDayLong
import com.boulangerie.presence.util.fmtDecimalHours
import com.boulangerie.presence.util.fmtDuration
import com.boulangerie.presence.util.fmtMonth
import com.boulangerie.presence.util.fmtTime
import com.boulangerie.presence.util.shareEmployeeCard
import com.boulangerie.presence.util.summarize

@Composable
fun BossScreen(vm: AppViewModel, onExit: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val titles = listOf("Aujourd'hui", "Employés", "Rapport", "Réglages")

    Column(Modifier.fillMaxSize()) {
        Header("Espace patron", "Quitter", onExit)
        TabRow(selectedTabIndex = tab) {
            titles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, maxLines = 1) })
            }
        }
        when (tab) {
            0 -> DayTab(vm)
            1 -> EmployeesTab(vm)
            2 -> ReportTab(vm)
            else -> SettingsTab(vm)
        }
    }
}

// ---------------------------------------------------------------- Aujourd'hui

@Composable
private fun DayTab(vm: AppViewModel) {
    val day by vm.selectedDay.collectAsState()
    val shifts by vm.dayShifts.collectAsState()
    val employees by vm.employees.collectAsState()
    val names = employees.associate { it.id to it.name }
    var toDelete by remember { mutableStateOf<Shift?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.shiftDay(-1) }) { Text("◀") }
            Text(
                fmtDayLong(day),
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            TextButton(onClick = { vm.shiftDay(1) }) { Text("▶") }
        }
        HorizontalDivider()

        if (shifts.isEmpty()) {
            Text("Aucun pointage ce jour-là.", modifier = Modifier.padding(24.dp))
        }
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(shifts, key = { it.id }) { s ->
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(names[s.employeeId] ?: "?", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        val out = s.checkOut
                        Text(
                            if (out != null)
                                "Arrivée ${fmtTime(s.checkIn)}  →  Départ ${fmtTime(out)}  (${fmtDuration(out - s.checkIn)})"
                            else
                                "Arrivée ${fmtTime(s.checkIn)}  →  en poste"
                        )
                        Row {
                            if (out == null) {
                                TextButton(onClick = { vm.closeShiftNow(s) }) { Text("Pointer le départ maintenant") }
                            }
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { toDelete = s }) { Text("Supprimer") }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Supprimer ce pointage ?") },
            text = { Text("${names[s.employeeId] ?: "?"} – arrivée ${fmtTime(s.checkIn)}") },
            confirmButton = {
                TextButton(onClick = { vm.deleteShift(s); toDelete = null }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Annuler") } }
        )
    }
}

// ---------------------------------------------------------------- Employés

@Composable
private fun EmployeesTab(vm: AppViewModel) {
    val employees by vm.employees.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var qrFor by remember { mutableStateOf<Employee?>(null) }

    Column(Modifier.fillMaxSize()) {
        Button(
            onClick = { showAdd = true },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) { Text("+ Ajouter un employé") }

        if (employees.isEmpty()) {
            Text("Aucun employé. Ajoutez-en un pour générer son QR code.", modifier = Modifier.padding(24.dp))
        }
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(employees, key = { it.id }) { e ->
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            if (e.role.isNotBlank()) Text(e.role)
                            Text(if (e.active) "Actif" else "Désactivé", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { qrFor = e }) { Text("QR code") }
                        Switch(checked = e.active, onCheckedChange = { vm.setActive(e, it) })
                    }
                }
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var role by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Nouvel employé") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true)
                    OutlinedTextField(role, { role = it }, label = { Text("Poste (boulanger, vendeuse…)") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = { vm.addEmployee(name, role); showAdd = false }
                ) { Text("Ajouter") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annuler") } }
        )
    }

    qrFor?.let { e ->
        val context = LocalContext.current
        val bitmap = remember(e.code) { employeeQr(e, 500) }
        AlertDialog(
            onDismissRequest = { qrFor = null },
            title = { Text(e.name) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Image(bitmap.asImageBitmap(), contentDescription = "QR code de ${e.name}", modifier = Modifier.size(240.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Imprimez la carte ou envoyez-la à l'employé. Ce QR code est personnel.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = { shareEmployeeCard(context, e) }) { Text("Partager / Imprimer") }
            },
            dismissButton = { TextButton(onClick = { qrFor = null }) { Text("Fermer") } }
        )
    }
}

// ---------------------------------------------------------------- Rapport

@Composable
private fun ReportTab(vm: AppViewModel) {
    val context = LocalContext.current
    val month by vm.selectedMonth.collectAsState()
    val shifts by vm.monthShifts.collectAsState()
    val employees by vm.employees.collectAsState()
    val rows = summarize(employees, shifts)

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.shiftMonth(-1) }) { Text("◀") }
            Text(
                fmtMonth(month),
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            TextButton(onClick = { vm.shiftMonth(1) }) { Text("▶") }
        }
        HorizontalDivider()

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (rows.isEmpty()) {
                item { Text("Aucune donnée pour ce mois.", modifier = Modifier.padding(12.dp)) }
            }
            items(rows, key = { it.employee.id }) { r ->
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(r.employee.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("${r.daysWorked} jour(s) travaillé(s)")
                        Text("Total : ${fmtDuration(r.totalMs)}  (${fmtDecimalHours(r.totalMs)} h)")
                        if (r.openShifts > 0) {
                            Text(
                                "${r.openShifts} départ(s) non pointé(s) – à corriger dans l'onglet Aujourd'hui",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        Button(
            onClick = { exportMonthCsv(context, month, employees, shifts) },
            enabled = shifts.isNotEmpty(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) { Text("Exporter en Excel (CSV) / partager") }
    }
}

// ---------------------------------------------------------------- Réglages

@Composable
private fun SettingsTab(vm: AppViewModel) {
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var defaultPin by remember { mutableStateOf(vm.isDefaultPin()) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Changer le code PIN", style = MaterialTheme.typography.titleLarge)
        if (defaultPin) {
            Text(
                "Vous utilisez encore le code par défaut (1234). Changez-le pour protéger les données.",
                color = MaterialTheme.colorScheme.error
            )
        }
        val keyboard = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        OutlinedTextField(
            oldPin, { oldPin = it.filter(Char::isDigit).take(8) },
            label = { Text("Ancien code") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = keyboard,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            newPin, { newPin = it.filter(Char::isDigit).take(8) },
            label = { Text("Nouveau code (4 à 8 chiffres)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = keyboard,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            confirm, { confirm = it.filter(Char::isDigit).take(8) },
            label = { Text("Confirmer le nouveau code") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = keyboard,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(
            onClick = {
                message = when {
                    newPin.length < 4 -> "Le nouveau code doit contenir au moins 4 chiffres."
                    newPin != confirm -> "Les deux nouveaux codes ne correspondent pas."
                    vm.changePin(oldPin, newPin) -> {
                        oldPin = ""; newPin = ""; confirm = ""
                        defaultPin = vm.isDefaultPin()
                        "Code PIN modifié."
                    }
                    else -> "Ancien code incorrect."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Enregistrer") }
        message?.let { Text(it) }
    }
}
