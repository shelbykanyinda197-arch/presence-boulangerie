package com.boulangerie.presence.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val role: String = "",
    /** Code secret contenu dans le QR code de l'employé. */
    val code: String,
    val active: Boolean = true
)

@Entity(tableName = "shifts", indices = [Index("employeeId")])
data class Shift(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val checkIn: Long,
    val checkOut: Long? = null
)

@Dao
interface AppDao {
    @Insert
    suspend fun insertEmployee(employee: Employee): Long

    @Update
    suspend fun updateEmployee(employee: Employee)

    @Query("SELECT * FROM employees ORDER BY name COLLATE NOCASE")
    fun employees(): Flow<List<Employee>>

    @Query("SELECT * FROM employees WHERE code = :code LIMIT 1")
    suspend fun employeeByCode(code: String): Employee?

    @Insert
    suspend fun insertShift(shift: Shift): Long

    @Update
    suspend fun updateShift(shift: Shift)

    @Query("DELETE FROM shifts WHERE id = :id")
    suspend fun deleteShift(id: Long)

    @Query("SELECT * FROM shifts WHERE employeeId = :employeeId AND checkOut IS NULL ORDER BY checkIn DESC LIMIT 1")
    suspend fun openShift(employeeId: Long): Shift?

    @Query("SELECT * FROM shifts WHERE employeeId = :employeeId ORDER BY checkIn DESC LIMIT 1")
    suspend fun lastShift(employeeId: Long): Shift?

    @Query("SELECT * FROM shifts WHERE checkIn >= :from AND checkIn < :to ORDER BY checkIn DESC")
    fun shiftsBetween(from: Long, to: Long): Flow<List<Shift>>
}

@Database(entities = [Employee::class, Shift::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "presence.db"
                ).build().also { instance = it }
            }
    }
}
