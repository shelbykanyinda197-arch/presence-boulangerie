package com.boulangerie.presence.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.core.content.FileProvider
import com.boulangerie.presence.data.Employee
import com.boulangerie.presence.data.QR_PREFIX
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream

fun qrBitmap(content: String, size: Int = 600): Bitmap {
    val hints = mapOf(
        EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
        EncodeHintType.MARGIN to 1
    )
    val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
    val pixels = IntArray(size * size)
    for (y in 0 until size) {
        for (x in 0 until size) {
            pixels[y * size + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
        }
    }
    return Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
}

fun employeeQr(employee: Employee, size: Int = 600): Bitmap = qrBitmap(QR_PREFIX + employee.code, size)

/** Carte à imprimer : nom de l'employé, QR code, nom de la boulangerie. */
fun employeeCard(employee: Employee): Bitmap {
    val width = 700
    val height = 900
    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    canvas.drawColor(Color.WHITE)

    val border = Paint().apply {
        color = Color.parseColor("#8B5A2B")
        style = Paint.Style.STROKE
        strokeWidth = 8f
    }
    canvas.drawRect(4f, 4f, width - 4f, height - 4f, border)

    val title = Paint().apply {
        color = Color.parseColor("#8B5A2B")
        textSize = 44f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    canvas.drawText("Carte de pointage", width / 2f, 80f, title)

    canvas.drawBitmap(employeeQr(employee, 560), (width - 560) / 2f, 120f, null)

    val name = Paint().apply {
        color = Color.BLACK
        textSize = 54f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    canvas.drawText(employee.name, width / 2f, 770f, name)

    if (employee.role.isNotBlank()) {
        val role = Paint().apply {
            color = Color.DKGRAY
            textSize = 38f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(employee.role, width / 2f, 830f, role)
    }
    return bmp
}

fun shareEmployeeCard(context: Context, employee: Employee) {
    val dir = File(context.cacheDir, "cards").apply { mkdirs() }
    val safeName = employee.name.replace(Regex("[^A-Za-z0-9]"), "_")
    val file = File(dir, "carte_${safeName}_${employee.id}.png")
    FileOutputStream(file).use { employeeCard(employee).compress(Bitmap.CompressFormat.PNG, 100, it) }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Partager ou imprimer la carte").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    })
}
