package com.boulangerie.presence.util

import com.boulangerie.presence.data.Employee
import com.boulangerie.presence.data.Shift

data class EmployeeSummary(
    val employee: Employee,
    val totalMs: Long,
    val daysWorked: Int,
    val openShifts: Int
)

/** Calcule, pour chaque employé, le total d'heures et le nombre de jours travaillés. */
fun summarize(employees: List<Employee>, shifts: List<Shift>): List<EmployeeSummary> {
    val byEmployee = shifts.groupBy { it.employeeId }
    return employees.mapNotNull { emp ->
        val list = byEmployee[emp.id].orEmpty()
        if (list.isEmpty() && !emp.active) return@mapNotNull null
        EmployeeSummary(
            employee = emp,
            totalMs = list.sumOf { s -> s.checkOut?.let { (it - s.checkIn).coerceAtLeast(0) } ?: 0L },
            daysWorked = list.map { dayOf(it.checkIn) }.distinct().size,
            openShifts = list.count { it.checkOut == null }
        )
    }
}
