package com.boulangerie.presence.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.boulangerie.presence.data.Employee
import com.boulangerie.presence.data.Shift
import java.io.File
import java.time.YearMonth

private fun csv(value: String): String =
    if (value.contains(';') || value.contains('"') || value.contains('\n'))
        "\"" + value.replace("\"", "\"\"") + "\""
    else value

/** Exporte le mois en CSV (séparateur ";" pour s'ouvrir directement dans Excel en français). */
fun exportMonthCsv(context: Context, month: YearMonth, employees: List<Employee>, shifts: List<Shift>) {
    val names = employees.associate { it.id to it.name }
    val sb = StringBuilder("﻿")

    sb.append("Détail des pointages - ").append(fmtMonth(month)).append('\n')
    sb.append("Employé;Date;Arrivée;Départ;Durée\n")
    shifts.sortedWith(compareBy<Shift>({ names[it.employeeId] ?: "" }, { it.checkIn })).forEach { s ->
        sb.append(csv(names[s.employeeId] ?: "?")).append(';')
            .append(fmtDayShort(s.checkIn)).append(';')
            .append(fmtTime(s.checkIn)).append(';')
            .append(s.checkOut?.let { fmtTime(it) } ?: "").append(';')
            .append(s.checkOut?.let { fmtDuration(it - s.checkIn) } ?: "départ non pointé")
            .append('\n')
    }

    sb.append('\n').append("Totaux du mois\n")
    sb.append("Employé;Jours travaillés;Total heures (h min);Total heures (décimal)\n")
    summarize(employees, shifts).forEach { r ->
        sb.append(csv(r.employee.name)).append(';')
            .append(r.daysWorked).append(';')
            .append(fmtDuration(r.totalMs)).append(';')
            .append(fmtDecimalHours(r.totalMs)).append('\n')
    }

    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
    val file = File(dir, "presence_${month}.csv")
    file.writeText(sb.toString(), Charsets.UTF_8)

    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Présences ${fmtMonth(month)}")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Envoyer le rapport").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    })
}
