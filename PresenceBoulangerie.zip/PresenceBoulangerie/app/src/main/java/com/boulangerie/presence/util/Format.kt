package com.boulangerie.presence.util

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val zone: ZoneId get() = ZoneId.systemDefault()
private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
private val dayFmt = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.FRENCH)
private val dayShortFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
private val monthFmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.FRENCH)

fun fmtTime(ms: Long): String = Instant.ofEpochMilli(ms).atZone(zone).format(timeFmt)

fun fmtDayLong(day: LocalDate): String = day.format(dayFmt).replaceFirstChar { it.uppercase() }

fun fmtDayShort(ms: Long): String = Instant.ofEpochMilli(ms).atZone(zone).format(dayShortFmt)

fun fmtMonth(month: YearMonth): String = month.format(monthFmt).replaceFirstChar { it.uppercase() }

/** 27 000 000 ms -> "7 h 30" */
fun fmtDuration(ms: Long): String {
    val totalMinutes = ms / 60_000
    val h = totalMinutes / 60
    val m = totalMinutes % 60
    return "$h h ${m.toString().padStart(2, '0')}"
}

/** Heures décimales, ex. "7,50" */
fun fmtDecimalHours(ms: Long): String = String.format(Locale.FRANCE, "%.2f", ms / 3_600_000.0)

fun startOfDayMillis(day: LocalDate): Long = day.atStartOfDay(zone).toInstant().toEpochMilli()

fun dayOf(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
